﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Net.NetworkInformation;



namespace NetDiag
{
    class Program
    {

       
        public static string GetPhysNetworkInterface2()
        {
            string s = "";
            s += "Analyse du réseau sur ce PC en cours...\n";
            s += "==========================================\n";
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();

            // for all network interfaces
            foreach (NetworkInterface adapter in nics)
            {
                // get only Ethernet and active adapters
                if (adapter.NetworkInterfaceType == NetworkInterfaceType.Ethernet && adapter.OperationalStatus == OperationalStatus.Up)
                {
                    IPInterfaceProperties adapterProperties = adapter.GetIPProperties();
                    IPv4InterfaceProperties p = adapterProperties.GetIPv4Properties();
                    //s += adapter.Description + "\n";
                    if (p.IsDhcpEnabled)
                    {
                        s += "Le DHCP de ce PC est activé\n";
                    }
                    else
                    {
                        s += "Le DHCP de ce PC n'est pas activé\n";
                    }
                    break; // get only 1st interface which should be the Ethernet wired connection instead of VM
                }
            }
            return s;
        }
        public static bool DhcpEnabled()
        {
            //bool[] dhcpState;
            int i = 0;
            NetworkInterface[] nics = NetworkInterface.GetAllNetworkInterfaces();
            
            // for all network interfaces
            for(i=0 ; i< nics.Length ; i++)
            {
                // get only Ethernet and active adapters
                if (nics[i].NetworkInterfaceType == NetworkInterfaceType.Ethernet && nics[i].OperationalStatus == OperationalStatus.Up)
                {
                    NetworkInterface nic0 = nics[i];
                    IPInterfaceProperties adapterProperties = nic0.GetIPProperties();
                    IPv4InterfaceProperties p = adapterProperties.GetIPv4Properties();
                    return p.IsDhcpEnabled;
                }
            }
            return false;
            //return dhcpState[0]; // get only 1st interface DHCP state which should be the Ethernet wired connection instead of VM
        }
    }
}

namespace Wpf_Detect_DHCP
{
    /// <summary>
    /// Logique d'interaction pour MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            string var = NetDiag.Program.GetPhysNetworkInterface2();
            InitializeComponent();
            displayStr(var);
        }
        private void displayStr(string s)
        {
            rapport_dhcp.Text = s;
            if (NetDiag.Program.DhcpEnabled()) // if DHCP enabled
            {
                button_name.Content = "DHCP activé. Cliquer pour un diagnostique";
            }
            else // if DHCP disabled
            {
                button_name.Content = "DHCP désactivé. Cliquer pour un diagnostique";
            }
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (NetDiag.Program.DhcpEnabled()) // if DHCP enabled
            {
                System.Diagnostics.Process.Start("https://www.citypassenger.com/dhcpok");
            }
            else // if DHCP disabled
            {
                System.Diagnostics.Process.Start("https://www.citypassenger.com/dhcpfail");
            }
        }
    }  
}


